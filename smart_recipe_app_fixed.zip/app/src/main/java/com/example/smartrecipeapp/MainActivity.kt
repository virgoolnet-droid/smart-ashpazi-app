package com.example.smartrecipeapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.smartrecipeapp.model.Ingredient
import com.example.smartrecipeapp.model.Recipe
import com.example.smartrecipeapp.model.Screen
import com.example.smartrecipeapp.ui.theme.SmartRecipeAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SmartRecipeAppTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    SmartRecipeApp()
                }
            }
        }
    }
}

@Composable
fun SmartRecipeApp() {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Inventory) }
    // Mutable inventory list maintained via state
    var inventory by remember { mutableStateOf(mutableListOf<Ingredient>()) }
    // Hard-coded recipes for the prototype. These would be fetched via an API in the future.
    val recipes = remember {
        listOf(
            Recipe(
                name = "املت گوجه‌فرنگی",
                ingredients = mapOf("تخم‌مرغ" to 2.0, "گوجه‌فرنگی" to 1.0, "روغن" to 10.0),
                description = "تخم‌مرغ‌ها را در ظرفی بشکنید و به همراه گوجه‌فرنگی خرد شده در روغن سرخ کنید."
            ),
            Recipe(
                name = "پاستا با سس پستو",
                ingredients = mapOf("پاستا" to 100.0, "سس پستو" to 50.0, "روغن زیتون" to 10.0),
                description = "پاستا را در آب جوش بپزید و سپس با سس پستو و روغن زیتون ترکیب کنید."
            ),
            Recipe(
                name = "سالاد سبزیجات",
                ingredients = mapOf("کاهو" to 50.0, "خیار" to 50.0, "گوجه" to 50.0),
                description = "تمام سبزیجات را خرد کنید و با سس دلخواه مخلوط نمایید."
            )
        )
    }

    when (val screen = currentScreen) {
        Screen.Inventory -> InventoryScreen(
            inventory = inventory,
            onAdd = { ing -> inventory = (inventory + ing).toMutableList() },
            onRemove = { ing -> inventory = inventory.filter { it != ing }.toMutableList() },
            onNext = { currentScreen = Screen.Suggestions }
        )
        Screen.Suggestions -> SuggestionsScreen(
            inventory = inventory,
            recipes = recipes,
            onSelect = { recipe ->
                // When a recipe is selected, deduct quantities from inventory
                val updated = inventory.map { ingredient ->
                    val required = recipe.ingredients[ingredient.name] ?: 0.0
                    ingredient.copy(quantity = (ingredient.quantity - required).coerceAtLeast(0.0))
                }.toMutableList()
                inventory = updated
                currentScreen = Screen.Detail(recipe)
            },
            onBack = { currentScreen = Screen.Inventory }
        )
        is Screen.Detail -> RecipeDetailScreen(
            recipe = screen.recipe,
            onBack = { currentScreen = Screen.Suggestions }
        )
    }
}

@Composable
fun InventoryScreen(
    inventory: List<Ingredient>,
    onAdd: (Ingredient) -> Unit,
    onRemove: (Ingredient) -> Unit,
    onNext: () -> Unit
) {
    var name by remember { mutableStateOf(TextFieldValue("")) }
    var quantity by remember { mutableStateOf(TextFieldValue("")) }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text(text = "مواد موجود", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("نام ماده") },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedTextField(
                value = quantity,
                onValueChange = { quantity = it },
                label = { Text("مقدار") },
                modifier = Modifier.width(100.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = {
                val qty = quantity.text.toDoubleOrNull()
                val title = name.text.trim()
                if (qty != null && title.isNotBlank()) {
                    onAdd(Ingredient(title, qty))
                    name = TextFieldValue("")
                    quantity = TextFieldValue("")
                }
            }) {
                Icon(Icons.Default.Add, contentDescription = "افزودن")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(inventory) { ingredient ->
                Card(modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Fastfood, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${ingredient.name} - ${ingredient.quantity} ${ingredient.unit}",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyLarge
                        )
                        IconButton(onClick = { onRemove(ingredient) }) {
                            Icon(
                                imageVector = Icons.Default.RemoveCircleOutline,
                                contentDescription = "حذف"
                            )
                        }
                    }
                }
            }
        }
        Button(
            onClick = { onNext() },
            modifier = Modifier.fillMaxWidth(),
            enabled = inventory.isNotEmpty()
        ) {
            Text("مشاهده غذاهای پیشنهادی")
        }
    }
}

@Composable
fun SuggestionsScreen(
    inventory: List<Ingredient>,
    recipes: List<Recipe>,
    onSelect: (Recipe) -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت")
            }
            Text(text = "غذاهای پیشنهادی", style = MaterialTheme.typography.titleLarge)
        }

        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            val inventoryMap = inventory.associateBy({ it.name }, { it.quantity })
            val availableRecipes = recipes.sortedByDescending { recipe ->
                // simple scoring: number of ingredients available
                recipe.ingredients.count { (name, qty) -> (inventoryMap[name] ?: 0.0) >= qty }
            }
            items(availableRecipes) { recipe ->
                val canMake = recipe.ingredients.all { (name, qty) ->
                    (inventoryMap[name] ?: 0.0) >= qty
                }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (canMake) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        contentColor = if (canMake) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Fastfood, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(recipe.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "مواد لازم: " + recipe.ingredients.keys.joinToString(separator = ", "),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Button(
                            onClick = { onSelect(recipe) },
                            enabled = canMake
                        ) {
                            Text("پخت")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecipeDetailScreen(
    recipe: Recipe,
    onBack: () -> Unit
) {
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onBack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "بازگشت")
            }
            Text(text = recipe.name, style = MaterialTheme.typography.titleLarge)
        }
        Spacer(modifier = Modifier.height(16.dp))
        // Ingredients list
        Text(text = "مواد لازم:", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        recipe.ingredients.forEach { (name, qty) ->
            Text(text = "• $name: ${qty}", style = MaterialTheme.typography.bodyLarge)
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "دستور پخت:", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = recipe.description, style = MaterialTheme.typography.bodyLarge)
        Spacer(modifier = Modifier.weight(1f))
        Button(onClick = { onBack() }, modifier = Modifier.fillMaxWidth()) {
            Text("بازگشت به لیست")
        }
    }
}