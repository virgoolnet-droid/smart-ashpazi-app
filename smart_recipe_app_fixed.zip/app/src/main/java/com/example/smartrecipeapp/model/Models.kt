package com.example.smartrecipeapp.model

/**
 * Represents an ingredient that exists in the user's pantry. Quantity is stored as a Double
 * for flexibility (e.g. grams, number of pieces). The unit can be displayed to the user separately.
 */
data class Ingredient(
    var name: String,
    var quantity: Double,
    var unit: String = "گرم"
)

/**
 * Represents a recipe with a name, a map of required ingredients with quantities, and
 * a textual description for the preparation steps.
 */
data class Recipe(
    val name: String,
    val ingredients: Map<String, Double>,
    val description: String
)

/**
 * Sealed class used for simple navigation within the app without a dedicated navigation library.
 */
sealed class Screen {
    object Inventory : Screen()
    object Suggestions : Screen()
    data class Detail(val recipe: Recipe) : Screen()
}