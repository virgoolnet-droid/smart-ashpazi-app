package com.example.smartrecipeapp.ui.theme

import androidx.compose.ui.graphics.Color

// Define the color palette matching the values defined in XML. Keeping the variables in Kotlin
// makes it easy to use them within Compose.

val md_theme_light_primary = Color(0xFF4CAF50)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFFC8E6C9)
val md_theme_light_onPrimaryContainer = Color(0xFF1B5E20)
val md_theme_light_secondary = Color(0xFF8BC34A)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFF1F8E9)
val md_theme_light_onSecondaryContainer = Color(0xFF33691E)
val md_theme_light_background = Color(0xFFFFFFFF)
val md_theme_light_onBackground = Color(0xFF1E1E1E)
val md_theme_light_surface = Color(0xFFFFFFFF)
val md_theme_light_onSurface = Color(0xFF1E1E1E)